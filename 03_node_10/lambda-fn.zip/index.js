'use strict'

exports.handler = async event => {
  console.log(event)
  return 'Hola Node en Vivo!'
}
